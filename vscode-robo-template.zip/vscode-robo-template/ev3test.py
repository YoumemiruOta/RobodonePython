#!/usr/bin/env python3
from time import sleep


from robodone_v2 import *

robo = Robot()


robo.debug_print('turn off LEDS')
robo.leds.all_off() # Turn all LEDs off
sleep(1)

# Set both pairs of LEDs to amber
robo.debug_print('turn on LEFT AMBER')
robo.leds.set_color('LEFT', 'AMBER')
sleep(1)
robo.debug_print('turn on RIGHT AMBER')
robo.leds.set_color('RIGHT', 'AMBER')

sleep(1)
robo.debug_print('turn off LEDS')
robo.leds.all_off() # Turn all LEDs off
sleep(1)


while True:
    if robo.btn.any():    # Checks if any button is pressed.
        robo.sound.beep()  # Wait for the beep to finish.
        exit()  # Stop the program.
    else:
        sleep(0.01)  # Wait 0.01 second
