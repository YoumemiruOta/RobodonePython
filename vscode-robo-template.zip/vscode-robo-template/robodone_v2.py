#!/usr/bin/env python3
# coding=utf-8
import os
import sys
import math
import random
from time import sleep,time


class Robot:
    import math
    import random
    from time import sleep

    def __init__(self):
        # import rpyc
        # self.msgflag = True
        self.import_ev3dev()

    def debug_print(*args, **kwargs):
        '''Print debug messages to stderr.

        This shows up in the output panel in VS Code.
        '''
        print(*args, **kwargs, file=sys.stderr)

    def import_ev3dev(self):
        from ev3dev2.led import Leds
        from ev3dev2.button import Button
        from ev3dev2.sound import Sound
        # self.ev3 = ev3
        self.leds = Leds()
        self.btn = Button()
        self.sound = Sound()

        # self.btn = self.ev3.Button()
        # return self.ev3

    # def connect_Lmotor(self,L='',R=''):
    #     if L != '':
    #         self.Lmotor_L = self.ev3.LargeMotor(L)
    #         self.Lmotor_L.reset()
    #     if R != '':
    #         self.Lmotor_R = self.ev3.LargeMotor(R)
    #         self.Lmotor_R.reset()

    # def connect_Mmotor(self,port=''):
    #     if port != '':
    #         self.Mmotor = self.ev3.MediumMotor(port)
    #         self.Mmotor.reset()

    # #--- ColorSensor
    # def connect_color(self):
    #     self.color = self.ev3.ColorSensor()
    #     self.set_color_mode()

    # def set_color_mode(self,mode=0):
    #     if mode == 0:
    #         self.color.mode= 'COL-REFLECT'
    #     elif mode == 1:
    #         self.color.mode= 'COL-COLOR'
    #     else :
    #         return

    # def get_color_value(self):
    #     return self.color.value()

    # #--- UltrasonicSensor
    # def connect_ultrasonic(self):
    #     self.us = self.ev3.UltrasonicSensor()
    #     self.set_us_mode()

    # def set_us_mode(self,mode=0):
    #     if mode == 0:
    #         self.us.mode= 'US-DIST-CM'
    #     else :
    #         return


    # def get_us_value(self):
    #     return self.us.value()/10

    # #--- TouchSensor
    # def connect_touch(self,L='',R=''):
    #     if L != '':
    #         self.ts1 = self.ev3.TouchSensor(L)
    #     if R != '':
    #         self.ts2 = self.ev3.TouchSensor(R)

    # def get_ts1_value(self):
    #     return self.ts1.value()

    # def get_ts2_value(self):
    #     return self.ts2.value()

    # #--- GyroSensor
    # def connect_gyro(self,port=''):
    #     if port!='':
    #         self.gy = self.ev3.GyroSensor()
    #         self.set_gyro_mode()

    # def set_gyro_mode(self,mode='GYRO-ANG'):
    #     if mode == 'GYRO-ANG':
    #         self.gy.mode= mode
    #     else :
    #         return

    # def get_gyro_value(self):
    #     return self.gy.value()

    # #--- timer block
    # def start_timer(self):
    #     self.timer_value = 0
    #     self.timer_start_value = time()

    # def stop_timer(self):
    #     self.timer_value = time() - self.timer_start_value

    # #--- Sound
    # def sound_play(self,fname='EV3'):
    #     soundfile = '/home/robot/sounds/'+fname+".wav"
    #     self.ev3.Sound().play(soundfile).wait()

    # def sound_speak(self,text='Hello E V 3'):
    #     self.ev3.Sound().speak(text).wait()

    # #--- LED Light block
    # def set_leds(self, mark='on', color='RED'):
    #     if mark=='off':
    #         self.leds.all_off()
    #     if mark=='on':
    #         if color == 'RED':
    #             self.leds.set_color(self.leds.LEFT,self.leds.RED)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.RED)
    #         elif color == 'GREEN':
    #             self.leds.set_color(self.leds.LEFT,self.leds.GREEN)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.GREEN)
    #         elif color == 'YELLOW':
    #             self.leds.set_color(self.leds.LEFT,self.leds.YELLOW)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.YELLOW)
    #         elif color == 'ORANGE':
    #             self.leds.set_color(self.leds.LEFT,self.leds.ORANGE)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.ORANGE)
    #         elif color == 'AMBER':
    #             self.leds.set_color(self.leds.LEFT,self.leds.AMBER)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.AMBER)
    #         else:
    #             self.leds.set_color(self.leds.LEFT,self.leds.RED)
    #             self.leds.set_color(self.leds.RIGHT,self.leds.RED)

    # #--- Mmotor block
    # def Mmotor_move(self, mark='on', pwr=10.0, target=0.0, msg=True):
    #     in_pwr = max(-100.,min(100.0,pwr))

    #     spd_M = max(-1000.,min(1000., 1000.*(in_pwr/100)))

    #     if (spd_M ==0):
    #         return 0

    #     if mark=='on':
    #         self.Mmotor.run_forever(speed_sp = spd_M)
    #     if mark=='pos':
    #         time_target = abs(target/spd_M)*1000
    #         self.Mmotor.run_timed(speed_sp = spd_M, time_sp = time_target,stop_action='hold')
    #         self.Mmotor.wait_while('running')

    #     if mark=='time':
    #         self.Mmotor.run_timed(speed_sp = spd_M, time_sp = target,stop_action='hold')
    #         self.Mmotor.wait_while('running')

    #     if mark=='off':
    #         self.Mmotor.stop(stop_action='brake')


    # #--- Lmotor(Left) block
    # def Lmotor_L_move(self, mark='on', pwr=10.0, target=0.0, msg=True):
    #     in_pwr = max(-100.,min(100.0,pwr))

    #     spd_L = max(-1000.,min(1000., 1000.*(in_pwr/100)))

    #     if (spd_L ==0):
    #         return

    #     if mark=='on':
    #         self.Lmotor_L.run_forever(speed_sp = spd_L)
    #     if mark=='pos':
    #         time_target = abs(target/spd_L)*1000
    #         self.Lmotor_L.run_timed(speed_sp = spd_L, time_sp = time_target,stop_action='hold')
    #         self.Lmotor_L.wait_while('running')

    #     if mark=='time':
    #         self.Lmotor_L.run_timed(speed_sp = spd_L, time_sp = target,stop_action='hold')
    #         if msg:
    #             self.Lmotor_L.wait_while('running')

    #     if mark=='off':
    #         self.msgflag = True
    #         self.Lmotor_L.stop(stop_action='brake')

    # #--- Lmotor(Right) block
    # def Lmotor_R_move(self, mark='on', pwr=10.0, target=0.0, msg=True):
    #     in_pwr = max(-100.,min(100.0,pwr))

    #     spd_R = max(-1000.,min(1000., 1000.*(in_pwr/100.)))

    #     if (spd_R ==0):
    #         return

    #     if mark=='on':
    #         self.Lmotor_R.run_forever(speed_sp = spd_R)
    #     if mark=='pos':
    #         time_target = abs(target/spd_R)*1000
    #         self.Lmotor_R.run_timed(speed_sp = spd_R, time_sp = time_target,stop_action='hold')


    #     if mark=='time':
    #         self.Lmotor_R.run_timed(speed_sp = spd_R, time_sp = target,stop_action='hold')
    #         if msg:
    #             self.Lmotor_R.wait_while('running')

    #     if mark=='off':
    #         self.msgflag = True
    #         self.Lmotor_R.stop(stop_action='brake')


    # #--- Steering block
    # def steering(self, mark='on', drc=0.0, pwr=10.0, target=10):
    #     in_dir = max(-100.,min(100.0,drc))
    #     in_pwr = max(-100.,min(100.0,pwr))
    #     pwr_L = in_pwr
    #     pwr_R = in_pwr
    #     if (in_pwr ==0):
    #         return
    #     if (target ==0):
    #         return
    #     if in_dir>=0:
    #         pwr_L = max(-100.,min(100., in_pwr))
    #         pwr_R = max(-100.,min(100., in_pwr*(1 - abs(in_dir)*0.01)))
    #     else:
    #         pwr_L = max(-100.,min(100., in_pwr*(1 - abs(in_dir)*0.01)))
    #         pwr_R = max(-100.,min(100., in_pwr))

    #     if mark=='on':
    #         if self.msgflag:
    #             self.msgflag = False
    #         self.Lmotor_L_move('on', pwr_L,0,False)
    #         self.Lmotor_R_move('on', pwr_R,0,False)
    #     if mark=='pos':
    #         time_L = 100000;
    #         time_R = 100000;
    #         if abs(pwr_L)>0:
    #             time_L = abs(target/pwr_L/10)*1000
    #         if abs(pwr_R)>0:
    #             time_R = abs(target/pwr_R/10)*1000
    #         time_target = min(time_L,time_R)


    #         self.Lmotor_L_move('time', pwr_L,time_target,False)
    #         self.Lmotor_R_move('time', pwr_R,time_target,False)
    #         if pwr_L!=0:
    #             self.Lmotor_L.wait_while('running')
    #         if pwr_R!=0:
    #             self.Lmotor_R.wait_while('running')

    #     if mark=='time':
    #         if (target <100):
    #             return

    #         self.Lmotor_L_move('time', pwr_L,target,False)
    #         self.Lmotor_R_move('time', pwr_R,target,False)
    #         if pwr_L!=0:
    #             self.Lmotor_L.wait_while('running')
    #         if pwr_R!=0:
    #             self.Lmotor_R.wait_while('running')
    #     if mark=='off':
    #         self.Lmotor_L_move('off')
    #         self.Lmotor_R_move('off')

    # #--- Tank block
    # def tank(self, mark='on', pwrL=10.0, pwrR=10.0, target=10.0):
    #     in_pwrL = max(-100.,min(100.0,pwrL))
    #     in_pwrR = max(-100.,min(100.0,pwrR))

    #     pwr_L = max(-100.,min(100., 100.*(in_pwrL/100)))
    #     pwr_R = max(-100.,min(100., 100.*(in_pwrR/100)))

    #     if (pwr_L ==0) and (pwr_R == 0):
    #         return
    #     if (target ==0):
    #         return

    #     if mark=='on':
    #         self.Lmotor_L_move('on', pwr_L,0,False)
    #         self.Lmotor_R_move('on', pwr_R,0,False)
    #     if mark=='pos':
    #         time_L = 100000;
    #         time_R = 100000;
    #         if abs(pwr_L)>0:
    #             time_L = abs(target/pwr_L/10)*1000
    #         if abs(pwr_R)>0:
    #             time_R = abs(target/pwr_R/10)*1000
    #         time_target = min(time_L,time_R)


    #         self.Lmotor_L_move('time', pwr_L,time_target,False)
    #         self.Lmotor_R_move('time', pwr_R,time_target,False)
    #         if pwr_L!=0:
    #             self.Lmotor_L.wait_while('running')
    #         if pwr_R!=0:
    #             self.Lmotor_R.wait_while('running')

    #     if mark=='time':
    #         self.Lmotor_L_move('time', pwr_L,time_target,False)
    #         self.Lmotor_R_move('time', pwr_R,time_target,False)
    #         if pwr_L!=0:
    #             self.Lmotor_L.wait_while('running')
    #         if pwr_R!=0:
    #             self.Lmotor_R.wait_while('running')

    #     if mark=='off':
    #         self.Lmotor_L_move('off')
    #         self.Lmotor_R_move('off')
